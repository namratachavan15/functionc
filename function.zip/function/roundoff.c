//Program to Round Off a Decimal or Floating-Point Number using function
#include<stdio.h>
float roundof(float);
int main()
{
  float no1,no2;
  printf("Enter Amount : ");
  scanf("%f",&no1);
  no2=roundof(no1);
  printf("\nafter rounding an Amount is= %f",no2); 
}
float roundof(float no1)
{
   int tmp1,tmp2;
   float b;
   tmp1=(int) no1;
   b=no1-tmp1;
   if(b>=0.5)
       return(tmp1+1);
   else
       return (tmp1);
}
