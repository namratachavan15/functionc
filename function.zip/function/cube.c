//find the cube of number using function
#include<conio.h>
int main()
{
 int no,a;
 int cube(int no);
 printf("\n enter no.");
 scanf("%d",&no);
 a=cube(no);
 printf("\n cube of give no.%d is %d",no,a);
}
int cube(int b)
{
   int tmp;
   tmp=b*b*b;
   return tmp;
}
