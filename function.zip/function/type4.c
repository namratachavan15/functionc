#include<stdio.h>
// function without argument & with return value
int main()
{
	int c;
	int sum();
	
	c=sum();
	printf("\nsum is=%d",c);
}
int sum()
{
	int a,b,c;
	printf("Enter values");
	scanf("%d%d",&a,&b);
	c=a+b;
    return c;
}
