//math.h Libraray function
#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,d,e,f;
	int number1 = -1234;
	double number = 123.54;
	double down, up;
	double result;
	double p = 3.0;
	double x = 3.0;
	double y = 4.0;

	double result1;
	double x1 = 4.0;

	printf("\nenter angle in degree");
	scanf("%f",&a);
	b=(a*3.14)/180;
	c=sin(b);
	d=cos(b);
	e=tan(b);
	f=log10(a);
	printf("\nsin=%f,\ncos=%f,\ntan=%f,log10=%f,",c,d,e,f);


	printf("number: %d  absolute value: %d\n", number1, abs(number1));

	down = floor(number);
	up = ceil(number);
	printf("original number     %0.2lf\n", number);
	printf("number rounded down %0.2lf\n", down);
	printf("number rounded up   %0.2lf\n", up);
	result = hypot(x, y);
	printf("The hypotenuse is: %lf\n", result);	
	result1 = exp(x1);
	printf("'e' raised to the power \of %lf (e ^ %lf) = %lf\n",x1, x1, result1);
    result1=pow(2,3);
    printf("\npower is=%lf",result1);
}





