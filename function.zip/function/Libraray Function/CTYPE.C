//ctype.h library function
#include<stdio.h>
#include<ctype.h>
int main()
{
   char tmp;
 
   printf("\nenter any char");
   scanf("%c",&tmp);
   if(isdigit(tmp))
      printf("\nDigit");
   if(isalpha(tmp))
      printf("\nAlpha");
   if(isupper(tmp))
      printf("\nUpper case");
   if(islower(tmp))
      printf("\nLower case");
   if(isalnum(tmp))
      printf("\nAlpha numric");
   if(isspace(tmp))
      printf("\nSpace");
   printf("\n%c",toupper(tmp));
   printf("\n%c",tolower(tmp));
   
}
