//string.h library function
#include<stdio.h>
#include<string.h>
int main()
{
  char name1[20],name2[20],name3[20];
  int a;
  
  printf("\n enter name:");
  scanf("%s",&name1);
  strupr(name1);
  printf("\n upper case:");
  puts(name1);
  strlwr(name1);
  printf("\n lower case:");
  puts(name1);
  strrev(name1);
  printf("\n reversed string is:");
  puts(name1);
  strrev(name1);
  printf("\n enter last name:");
  scanf("%s",&name2);
  strcpy(name3,name1);
  strcat(name3," ");
  strcat(name3,name2);
  printf("\n concated string is:");
  puts(name3);
  a=strlen(name3);
  printf("\n length=%d",a);
  
}
