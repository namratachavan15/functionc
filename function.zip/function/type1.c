
// function without argument & without return value
#include<stdio.h>
int main()
{
	void sum();
	
	sum();
}
void sum()
{
	int a,b,c;
	printf("Enter values");
	scanf("%d%d",&a,&b);
	c=a+b;
	printf("\nsum is=%d",c);
}
