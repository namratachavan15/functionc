
// function with argument & without return value
#include<stdio.h>
int main()
{
	int a,b;
	void sum(int,int);
	printf("Enter values");
	scanf("%d%d",&a,&b);
	sum(a,b);
}
void sum(int p,int q)
{
	int c;

	c=p+q;
	printf("\nsum is=%d",c);
}
