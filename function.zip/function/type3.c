#include<stdio.h>
// function with argument & with return value
int main()
{
	int a,b,c;
	int sum(int,int);
	printf("Enter values");
	scanf("%d%d",&a,&b);
	c=sum(a,b);
	printf("\nsum is=%d",c);
}
int sum(int p,int q)
{
	int c;
	c=p+q;
 	return c;
}
